<?php return array('dependencies' => array('wp-components', 'wp-element', 'wp-i18n'), 'version' => '23c13c1f3cab49569340');
