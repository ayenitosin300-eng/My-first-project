<?php
$html_1 = get_theme_mod( 'zakra_footer_html_1', '' );
echo '<div class="zak-html-1">';
echo $html_1;
echo '</div>';
