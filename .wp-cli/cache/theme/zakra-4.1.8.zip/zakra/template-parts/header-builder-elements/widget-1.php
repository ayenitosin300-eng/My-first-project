<?php

dynamic_sidebar( 'top-bar-col-1-sidebar' );
