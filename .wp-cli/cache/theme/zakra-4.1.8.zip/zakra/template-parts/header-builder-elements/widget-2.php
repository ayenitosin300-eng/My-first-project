<?php

dynamic_sidebar( 'top-bar-col-2-sidebar' );
