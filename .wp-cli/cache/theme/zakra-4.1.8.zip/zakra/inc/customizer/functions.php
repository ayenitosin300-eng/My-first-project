<?php
/** @return \customizer\customind\core\Customind */
function zakra_customind() {
	global $customind;
	return $customind;
}
