<?php
/**
 * Layout template.
 */

defined( 'ABSPATH' ) || exit;
?>
<div id="render_dashboard_page"></div>
