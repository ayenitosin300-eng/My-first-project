export enum PanelTypes {
	'GENERAL' = 'General',
	'HEADER' = 'Header',
	'PRIMARYMENU' = 'primaryMenu',
	'PAGEHEADER' = 'pageHeader',
}
