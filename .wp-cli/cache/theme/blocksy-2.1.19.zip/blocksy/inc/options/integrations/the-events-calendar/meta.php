<?php

$options = blocksy_get_options('meta/default', [
	'post_type' => get_post_type_object('tribe_events'),
	'has_post_elements' => false
]);

