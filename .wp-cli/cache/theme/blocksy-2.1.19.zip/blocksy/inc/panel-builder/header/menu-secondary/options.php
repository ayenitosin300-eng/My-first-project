<?php

$options = blocksy_get_options(
	get_template_directory() . '/inc/panel-builder/header/menu/options.php',
    [
        'location' => 'Header Menu 2'
    ],
	false
);

