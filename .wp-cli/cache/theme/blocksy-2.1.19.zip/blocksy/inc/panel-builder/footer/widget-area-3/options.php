<?php

$options = blocksy_get_options(
	get_template_directory() . '/inc/panel-builder/footer/widget-area-1/options.php',
	[
		'sidebarId' => 'ct-footer-sidebar-3'
	],
	false
);

