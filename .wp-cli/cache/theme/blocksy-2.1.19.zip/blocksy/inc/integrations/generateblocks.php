<?php

// add_filter('generateblocks_global_css_priority', function ($current) {
// 	return 55;
// });

// add_filter('generateblocks_dynamic_css_priority', function ($current) {
// 	return 60;
// });