<?php

namespace Customind\Core\Types\Controls;

class ColorGroup extends AbstractGroupControl {
	public $type = 'customind-color-group';
}
