<?php
/**
 * Technology starter content.
 *
 * @package ColorMag\Compatibility\Starter_Content
 */

return [
	'post_type'    => 'page',
	'post_title'   => _x( 'Technology', 'Theme starter content', 'colormag' ),
	'post_content' => '',
];
