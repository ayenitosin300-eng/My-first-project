<?php
/**
 * Index file
 *
 * @package Bstone
 * @since Bstone 1.0.0
 */

/* Silence is golden, and we agree. */
