<?php
/**
 * Elementor Compatibility File.
 *
 * @package Bstone
 */

namespace Elementor;// phpcs:ignore PHPCompatibility.Keywords.NewKeywords.t_namespaceFound

// If plugin - 'Elementor' not exist then return.
if ( ! class_exists( '\Elementor\Plugin' ) ) {
	return;
}

/**
 * Bstone Elementor Compatibility
 */
if ( ! class_exists( 'Bstone_Elementor' ) ) :

    /**
	 * Bstone Elementor Compatibility
	 *
	 * @since 1.0.0
	 */
    class Bstone_Elementor {

        /**
		 * Member Variable
		 *
		 * @var object instance
		 */
		private static $instance;

		/**
		 * Initiator
		 */
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

        /**
		 * Constructor
		 */
		public function __construct() {
            
		}
    }

endif;

/**
 * Kicking this off by calling 'get_instance()' method
 */
Bstone_Elementor::get_instance();