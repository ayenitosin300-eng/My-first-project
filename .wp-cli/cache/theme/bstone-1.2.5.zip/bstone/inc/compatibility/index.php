<?php
/**
 * Index file
 *
 * @package Bstone
 * @since Bstone 1.1.6
 */

/* Silence is golden, and we agree. */
