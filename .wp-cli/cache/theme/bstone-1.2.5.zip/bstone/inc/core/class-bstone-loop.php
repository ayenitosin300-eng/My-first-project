<?php
/**
 * Bstone Loop
 *
 * @package Bstone
 * @since 1.2.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'Bstone_Loop' ) ) :

	/**
	 * Bstone_Loop
	 *
	 * @since 1.2.2
	 */
	class Bstone_Loop {
        
    }
endif;