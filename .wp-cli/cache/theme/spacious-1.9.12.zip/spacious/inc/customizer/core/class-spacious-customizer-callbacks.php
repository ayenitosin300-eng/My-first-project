<?php
/**
 * Spacious customizer class for theme customize callbacks.
 *
 * Class Spacious_Customizer_FrameWork_FrameWork_Callbacks
 *
 * @package    ThemeGrill
 * @subpackage Spacious
 * @since      Spacious 3.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Spacious customizer class for theme customize callbacks.
 *
 * Class Spacious_Customizer_FrameWork_Callbacks
 */
class Spacious_Customizer_FrameWork_Callbacks {

}
