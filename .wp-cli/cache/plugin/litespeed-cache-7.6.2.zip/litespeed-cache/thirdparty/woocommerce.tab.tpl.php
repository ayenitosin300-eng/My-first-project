<?php
/**
 * WooCommerce tab template for LiteSpeed Cache plugin.
 *
 * @package LiteSpeed
 */

defined( 'WPINC' ) || exit;
?>

<a class='litespeed-tab nav-tab' href='#woocommerce' data-litespeed-tab='woocommerce'>WooCommerce</a>
