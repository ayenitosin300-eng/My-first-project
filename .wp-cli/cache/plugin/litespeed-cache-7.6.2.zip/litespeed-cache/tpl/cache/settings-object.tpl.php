<?php
/**
 * LiteSpeed Cache Object Cache Settings
 *
 * @package LiteSpeed
 * @since 1.0.0
 */

namespace LiteSpeed;

defined( 'WPINC' ) || exit;

require LSCWP_DIR . 'tpl/cache/settings_inc.object.tpl.php';
