<?php return array('dependencies' => array('lodash', 'wp-data', 'wp-notices'), 'version' => '89484f9388cf6ea2d413');
