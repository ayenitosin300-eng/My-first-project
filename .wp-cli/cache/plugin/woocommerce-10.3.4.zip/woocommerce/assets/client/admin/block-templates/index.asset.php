<?php return array('dependencies' => array('wc-settings', 'wp-block-editor', 'wp-blocks', 'wp-core-data', 'wp-data', 'wp-element'), 'version' => 'b3e63b3af3204f8c7929');
