<?php return array('dependencies' => array(), 'version' => '566af0e2bd0969360ba3');
