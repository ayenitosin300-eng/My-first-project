<?php
defined('ABSPATH') or die();

/**
 * @param $fields
 *
 * @return mixed
 */
function rsssl_mails(){
	return apply_filters('rsssl_mails', [

	]);
}


