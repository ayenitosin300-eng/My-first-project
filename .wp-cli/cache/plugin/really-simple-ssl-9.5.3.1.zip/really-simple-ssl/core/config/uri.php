<?php if (!defined('ABSPATH')) {
    exit;
}

return [
    'rsp' => [
        'mailinglist' => 'https://mailinglist.really-simple-ssl.com',
        'upgrade_from_free' => 'https://really-simple-ssl.com/pro?mtm_campaign=security&mtm_source=free&mtm_content=upgrade',
    ]
];