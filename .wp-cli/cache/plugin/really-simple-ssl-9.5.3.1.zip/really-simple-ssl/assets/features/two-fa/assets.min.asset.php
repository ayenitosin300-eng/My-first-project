<?php return array('dependencies' => array(), 'version' => '2e3203f2950282bc4eb6');
